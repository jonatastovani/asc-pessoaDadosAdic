-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: ascclub
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ascclub`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ascclub` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `ascclub`;

--
-- Table structure for table `pessoa_cadastro`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `pessoa_cadastro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categ` varchar(50) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `abrev` varchar(50) NOT NULL,
  `link_erp` varchar(5) DEFAULT NULL,
  `matric` int(11) NOT NULL,
  `matric_dig` int(2) NOT NULL DEFAULT 1,
  `titulo` int(11) NOT NULL,
  `sit_titulo` varchar(15) NOT NULL,
  `data_admissao` date NOT NULL,
  `data_cadastro` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `data_atualizacao` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matric` (`matric`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoa_cadastro`
--

INSERT INTO `pessoa_cadastro` (`id`, `categ`, `nome`, `abrev`, `link_erp`, `matric`, `matric_dig`, `titulo`, `sit_titulo`, `data_admissao`, `data_cadastro`, `data_atualizacao`) VALUES (1,'Efetivo Fundador','João Silva','JS','ERP1',12345,1,1234,'Livre','2023-08-01','2023-09-10 13:52:02.777001',NULL),(2,'Efetivo Fundador','Maria Santos','MS','ERP2',54321,1,6543,'Livre','2023-07-15','2023-09-10 13:52:02.777407',NULL),(3,'Efetivo Fundador','Carlos Ferreira','CF','ERP3',98765,1,15987,'Livre','2023-08-10','2023-09-10 13:52:02.777669',NULL),(4,'Efetivo Fundador','Ana Oliveira','AO','ERP4',24680,1,32478,'Livre','2023-07-20','2023-09-10 13:52:02.777946',NULL);

--
-- Table structure for table `pessoa_contato_emerg`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `pessoa_contato_emerg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pessoa` int(11) NOT NULL,
  `fam1` varchar(255) DEFAULT NULL,
  `telfam1` varchar(11) DEFAULT NULL,
  `fam2` varchar(255) DEFAULT NULL,
  `telfam2` varchar(11) DEFAULT NULL,
  `medic` varchar(255) DEFAULT NULL,
  `telmedic` varchar(11) DEFAULT NULL,
  `conv` varchar(100) DEFAULT NULL,
  `hosp` varchar(255) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `data_atualizado` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_pessoa` (`id_pessoa`),
  CONSTRAINT `pessoa_contato_emerg_ibfk_1` FOREIGN KEY (`id_pessoa`) REFERENCES `pessoa_cadastro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoa_contato_emerg`
--

INSERT INTO `pessoa_contato_emerg` (`id`, `id_pessoa`, `fam1`, `telfam1`, `fam2`, `telfam2`, `medic`, `telmedic`, `conv`, `hosp`, `obs`, `data_cadastro`, `data_atualizado`) VALUES (1,1,'Nome de familiar 1\'apostrofo','1934695727','Familiar','1934695245','Médico de Emergência','1934696367','Convênio São Francisco','Hospital Samaritano','Observações dos contatos','2023-09-03 06:44:39','2023-09-03 11:44:39'),(2,2,'Familiar 3','11122233301',NULL,NULL,'Médico Principal','44455566601',NULL,'Hospital 123','Observações sobre contato de emergência para Pessoa 2','2023-09-03 05:16:24',NULL);

--
-- Table structure for table `pessoa_dados_pessoais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `pessoa_dados_pessoais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pessoa` int(11) NOT NULL,
  `end_cep` varchar(8) NOT NULL,
  `end_logr` varchar(255) NOT NULL,
  `end_num` varchar(6) NOT NULL,
  `end_bair` varchar(100) NOT NULL,
  `end_ref` varchar(100) DEFAULT NULL,
  `end_cid` varchar(255) NOT NULL,
  `end_est` varchar(2) NOT NULL,
  `tel1` varchar(11) DEFAULT NULL,
  `tel2` varchar(11) DEFAULT NULL,
  `tel3` varchar(11) DEFAULT NULL,
  `tipo_doc` varchar(11) DEFAULT NULL,
  `doc` varchar(14) NOT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `oe` varchar(30) DEFAULT NULL,
  `nacio` varchar(100) DEFAULT NULL,
  `natur` varchar(100) DEFAULT NULL,
  `est_civ` varchar(30) DEFAULT NULL,
  `escol` varchar(30) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `situacao` varchar(30) DEFAULT NULL,
  `data_falec` date DEFAULT NULL,
  `email_pess` varchar(100) DEFAULT NULL,
  `sexo` varchar(1) DEFAULT NULL,
  `email_bol` varchar(100) DEFAULT NULL,
  `email_adic` varchar(255) DEFAULT NULL,
  `trat_pess` varchar(30) DEFAULT NULL,
  `socio_cons` varchar(30) DEFAULT NULL,
  `data_vinc` date DEFAULT NULL,
  `data_ret_sit` date DEFAULT NULL,
  `sit_ret` varchar(30) DEFAULT NULL,
  `quadro` varchar(30) DEFAULT NULL,
  `matr_opc` varchar(6) DEFAULT NULL,
  `data_desl` date DEFAULT NULL,
  `termo` varchar(30) DEFAULT NULL,
  `obs` varchar(30) DEFAULT NULL,
  `data_cadastro` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `data_atualizacao` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_pessoa` (`id_pessoa`),
  UNIQUE KEY `doc` (`doc`),
  UNIQUE KEY `email_pess` (`email_pess`),
  CONSTRAINT `pessoa_dados_pessoais_ibfk_1` FOREIGN KEY (`id_pessoa`) REFERENCES `pessoa_cadastro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoa_dados_pessoais`
--

INSERT INTO `pessoa_dados_pessoais` (`id`, `id_pessoa`, `end_cep`, `end_logr`, `end_num`, `end_bair`, `end_ref`, `end_cid`, `end_est`, `tel1`, `tel2`, `tel3`, `tipo_doc`, `doc`, `rg`, `oe`, `nacio`, `natur`, `est_civ`, `escol`, `data_nasc`, `situacao`, `data_falec`, `email_pess`, `sexo`, `email_bol`, `email_adic`, `trat_pess`, `socio_cons`, `data_vinc`, `data_ret_sit`, `sit_ret`, `quadro`, `matr_opc`, `data_desl`, `termo`, `obs`, `data_cadastro`, `data_atualizacao`) VALUES (1,1,'13456082','Rua Caiapós','12345','Jardim São Francisco','Perto do coiso','Santa Bárbara D\'Oeste','SP','18997010088','19992976962','19997940209','cnpj','37447023000159','45.496.471-7','12345','Brasileiro','Flórida Paulista','SP','Superior Completo','1995-03-22','Ativo','2001-01-01','ravel22031995@gmail.com','M','ravel22031995@gmail.com','ravel22031995@gmail.com','TB','sim','2022-06-15','2021-10-18','Blabla','Técnico','2222','2023-01-02','Nenhum termo','Nenhuma observação','2023-09-12 18:53:05.919623','2023-09-12 23:53:05.000000'),(15,2,'13456082','Rua Caiapós','12345','Jardim São Francisco','','Santa Bárbara D\'Oeste','SP','18997010088','','','cpf','44764002809','','','','','SP','','1995-03-22','','0000-00-00','dani230697@gmail.com','M','','','','','0000-00-00','0000-00-00','','','','0000-00-00','','','2023-09-13 04:16:40.000000',NULL);

--
-- Dumping routines for database 'ascclub'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-15  7:23:53
